package com.sunrise.card.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.sunrise.card.dto.Commcodedtl;
import com.sunrise.card.dto.Rcvappl;

@Repository("CardDaoImpl")
public class CardDaoImpl implements CardDao {

	@Autowired
	SqlSession sql;

	// 등록(최초신규)
	@Override
	public void InsertCard(Rcvappl rcv) throws Exception {
		sql.insert("Card.InsertCard", rcv);
	}

	// 신청구분 select box
	@Override
	public List<Commcodedtl> appcategory() throws Exception {
		return sql.selectList("Card.appcategory");
	}

	// 브랜드 select box
	@Override
	public List<Commcodedtl> brand() throws Exception {
		return sql.selectList("Card.brand");
	}

	// 결제일자 select box
	@Override
	public List<Commcodedtl> paymentdate() throws Exception {
		return sql.selectList("Card.paymentdate");
	}

	// 결제방법 select box
	@Override
	public List<Commcodedtl> paymentmethod() throws Exception {
		return sql.selectList("Card.paymentmethod");
	}

	// 결제방법 select box
	@Override
	public List<Commcodedtl> paymentbank() throws Exception {
		return sql.selectList("Card.paymentbank");
	}

	// 청구서 발송방법 select box
	@Override
	public List<Commcodedtl> billsendmethod() throws Exception {
		return sql.selectList("Card.billsendmethod");
	}

}
