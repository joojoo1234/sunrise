package com.sunrise.card.dao;

import java.util.List;

import com.sunrise.card.dto.Commcodedtl;
import com.sunrise.card.dto.Rcvappl;
import com.sunrise.card.service.*;

public interface CardDao {

	// 등록(최초신규)
	public void InsertCard(Rcvappl rcv) throws Exception;

	// 신청구분 select box
	public List<Commcodedtl> brand() throws Exception;

	// 브랜드 select box
	public List<Commcodedtl> appcategory() throws Exception;

	// 결제일자 select box
	public List<Commcodedtl> paymentdate() throws Exception;

	// 결제방법 select box
	public List<Commcodedtl> paymentmethod() throws Exception;

	// 결제은행 select box
	public List<Commcodedtl> paymentbank() throws Exception;

	// 청구서 발송방법 select box
	public List<Commcodedtl> billsendmethod() throws Exception;
}
