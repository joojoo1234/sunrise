package com.sunrise.card.service;

import java.util.List;

import com.sunrise.card.dto.Commcodedtl;
import com.sunrise.card.dto.Rcvappl;

public interface CardService {

	// 등록(최초신규)
	public void InsertCard(Rcvappl rcv) throws Exception;

	// 신청구분 select box
	List<Commcodedtl> appcategory() throws Exception;

	// 브랜드 select box
	List<Commcodedtl> brand() throws Exception;

	// 결제일자 select box
	List<Commcodedtl> paymentdate() throws Exception;

	// 결제방법 select box
	List<Commcodedtl> paymentmethod() throws Exception;

	// 결제은행 select box
	List<Commcodedtl> paymentbank() throws Exception;

	// 청구서 발송방법 select box
	List<Commcodedtl> billsendmethod() throws Exception;
}
