package com.sunrise.card.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunrise.card.dao.CardDao;
import com.sunrise.card.dto.Commcodedtl;
import com.sunrise.card.dto.Rcvappl;

@Service("CardServiceImpl")
public class CardServiceImpl implements CardService {

	@Autowired
	private CardDao CDao;

	// 등록(최초신규)
	@Override
	public void InsertCard(Rcvappl rcv) throws Exception {
		CDao.InsertCard(rcv);

	}

	// 신청구분 select box
	@Override
	public List<Commcodedtl> appcategory() throws Exception {
		List<Commcodedtl> appcategory = CDao.appcategory();
		return appcategory;
	}

	// 브랜드 select box
	@Override
	public List<Commcodedtl> brand() throws Exception {
		List<Commcodedtl> brand = CDao.brand();
		return brand;
	}

	// 결제일자 select box
	@Override
	public List<Commcodedtl> paymentdate() throws Exception {
		List<Commcodedtl> paymentdate = CDao.paymentdate();
		return paymentdate;
	}

	// 결제방법 select box
	@Override
	public List<Commcodedtl> paymentmethod() throws Exception {
		List<Commcodedtl> paymentmethod = CDao.paymentmethod();
		return paymentmethod;
	}

	// 결제은행 select box
	@Override
	public List<Commcodedtl> paymentbank() throws Exception {
		List<Commcodedtl> paymentbank = CDao.paymentbank();
		return paymentbank;
	}

	// 청구서 발송방법 select box
	@Override
	public List<Commcodedtl> billsendmethod() throws Exception {
		List<Commcodedtl> billsendmethod = CDao.billsendmethod();
		return billsendmethod;
	}
}
