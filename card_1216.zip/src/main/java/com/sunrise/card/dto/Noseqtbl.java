package com.sunrise.card.dto;

public class Noseqtbl {
	
	private String RCV_SEQ_NO;
	private String RCV_D;
	
	public String getRCV_SEQ_NO() {
		return RCV_SEQ_NO;
	}
	public void setRCV_SEQ_NO(String rCV_SEQ_NO) {
		RCV_SEQ_NO = rCV_SEQ_NO;
	}
	public String getRCV_D() {
		return RCV_D;
	}
	public void setRCV_D(String rCV_D) {
		RCV_D = rCV_D;
	}

	
}
