package com.sunrise.card.dto;

public class Seqnotbl {
	private String CUST_NO;
	private String CRD_NO;
	
	public String getCUST_NO() {
		return CUST_NO;
	}
	public void setCUST_NO(String cUST_NO) {
		CUST_NO = cUST_NO;
	}
	public String getCRD_NO() {
		return CRD_NO;
	}
	public void setCRD_NO(String cRD_NO) {
		CRD_NO = cRD_NO;
	}
	

}
