package com.sunrise.card.dto;

public class Cust {
	
	private String CUST_NO;
    private String SSN;
	private String REG_D;
    private String HG_NM;
    private String BIRTH_D;
    private String HDP_NO;
    private String LST_OPR_TM;
    private String LST_OPR_D;
    private String LST_OPRT_EMPNO;
    
    public String getCUST_NO() {
		return CUST_NO;
	}
	public void setCUST_NO(String cUST_NO) {
		CUST_NO = cUST_NO;
	}
	public String getSSN() {
		return SSN;
	}
	public void setSSN(String sSN) {
		SSN = sSN;
	}
	public String getREG_D() {
		return REG_D;
	}
	public void setREG_D(String rEG_D) {
		REG_D = rEG_D;
	}
	public String getHG_NM() {
		return HG_NM;
	}
	public void setHG_NM(String hG_NM) {
		HG_NM = hG_NM;
	}
	public String getBIRTH_D() {
		return BIRTH_D;
	}
	public void setBIRTH_D(String bIRTH_D) {
		BIRTH_D = bIRTH_D;
	}
	public String getHDP_NO() {
		return HDP_NO;
	}
	public void setHDP_NO(String hDP_NO) {
		HDP_NO = hDP_NO;
	}
	public String getLST_OPR_TM() {
		return LST_OPR_TM;
	}
	public void setLST_OPR_TM(String lST_OPR_TM) {
		LST_OPR_TM = lST_OPR_TM;
	}
	public String getLST_OPR_D() {
		return LST_OPR_D;
	}
	public void setLST_OPR_D(String lST_OPR_D) {
		LST_OPR_D = lST_OPR_D;
	}
	public String getLST_OPRT_EMPNO() {
		return LST_OPRT_EMPNO;
	}
	public void setLST_OPRT_EMPNO(String lST_OPRT_EMPNO) {
		LST_OPRT_EMPNO = lST_OPRT_EMPNO;
	}
    
    
}