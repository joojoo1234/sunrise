package com.sunrise.card.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sunrise.card.HomeController;
import com.sunrise.card.dao.CardDao;
import com.sunrise.card.dto.Commcodedtl;
import com.sunrise.card.dto.Rcvappl;
import com.sunrise.card.service.CardService;
import com.sunrise.card.service.CardServiceImpl;

@Controller
public class MainController {

	@Autowired
	CardService CService;

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);


	// 회원 입회신청으로 이동
	@RequestMapping(value = "createcard", method = RequestMethod.GET)
	public String home2(Locale locale, Model model) throws Exception {
		List<Commcodedtl> appcategory = CService.appcategory();
		List<Commcodedtl> brand = CService.brand();
		List<Commcodedtl> paymentdate = CService.paymentdate();
		List<Commcodedtl> paymentmethod = CService.paymentmethod();
		List<Commcodedtl> paymentbank = CService.paymentbank();
		List<Commcodedtl> billsendmethod = CService.billsendmethod();
		logger.info("success select");
		model.addAttribute("appcategory", appcategory);
		model.addAttribute("brand", brand);
		model.addAttribute("paymentdate", paymentdate);
		model.addAttribute("paymentmethod", paymentmethod);
		model.addAttribute("paymentbank", paymentbank);
		model.addAttribute("billsendmethod", billsendmethod);
		return "createcard";
	}

	// 등록(최초신규)
	@RequestMapping(value = "createcard", method = RequestMethod.POST)
	public String home3(Rcvappl rcv) throws Exception {
		CService.InsertCard(rcv);
		logger.info("success create");
		return "redirect:/home";
	}

	// 회원 입회신청내역으로 이동
	@RequestMapping(value = "lookupcard", method = RequestMethod.GET)
	public String home4(Locale locale, Model model) {
		logger.info("success lookupcard");

		return "lookupcard";
	}

}
